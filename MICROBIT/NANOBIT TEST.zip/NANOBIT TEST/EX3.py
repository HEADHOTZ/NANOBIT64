from microbit import *
import tm1637
Min = 10
Sec = 30

while True:
    tm.number(Min, Sec)


